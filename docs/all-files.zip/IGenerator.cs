using RuleGenerator.Models;

namespace RuleGenerator.Generators;

/// <summary>
/// Common interface for all code generators.
/// Each generator receives the fully resolved domain and writes
/// one or more output files to the specified directory.
/// </summary>
public interface IGenerator
{
    string Name { get; }
    Task GenerateAsync(ResolvedDomain domain, string outputPath);
}
