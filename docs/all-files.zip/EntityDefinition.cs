namespace RuleGenerator.Models;

/// <summary>
/// Root container for entity definitions loaded from entities.yaml
/// </summary>
public class EntityDefinitions
{
    public string Version { get; set; } = "1.0";
    public List<EntityDefinition> Entities { get; set; } = new();
}

/// <summary>
/// A domain entity that maps to a database table.
/// Fields reference types and enums from PreparedItems.
/// </summary>
public class EntityDefinition
{
    /// <summary>PascalCase entity name e.g. Order, OrderLine</summary>
    public string Id { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// Postgres table name override. Defaults to snake_case of Id.
    /// e.g. OrderLine → order_lines
    /// </summary>
    public string? Table { get; set; }

    public List<FieldDefinition> Fields { get; set; } = new();
    public List<IndexDefinition> Indexes { get; set; } = new();

    /// <summary>
    /// If true, generator adds createdAt, updatedAt, createdById audit fields.
    /// </summary>
    public bool Audit { get; set; }

    /// <summary>
    /// If true, generator adds deletedAt instead of hard deletes.
    /// </summary>
    public bool SoftDelete { get; set; }
}

/// <summary>
/// A single field on an entity.
/// </summary>
public class FieldDefinition
{
    /// <summary>camelCase field name e.g. creditLimit, orderStatus</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Resolved in this order:
    ///   1. Prepared item type id       e.g. email, money
    ///   2. Prepared item enum id       e.g. order_status
    ///   3. Primitive                   e.g. text, integer, boolean, uuid,
    ///                                       decimal, timestamp, date, jsonb
    ///   4. "reference"                 → use Entity property
    /// </summary>
    public string Type { get; set; } = string.Empty;

    /// <summary>Target entity id for reference fields.</summary>
    public string? Entity { get; set; }

    public bool Required { get; set; } = true;
    public bool Unique { get; set; }
    public bool PrimaryKey { get; set; }
    public object? Default { get; set; }
    public string Description { get; set; } = string.Empty;
}

/// <summary>
/// An additional index on an entity beyond the primary key.
/// </summary>
public class IndexDefinition
{
    public List<string> Fields { get; set; } = new();
    public bool Unique { get; set; }
    public string? Name { get; set; }
}
