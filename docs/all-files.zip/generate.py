#!/usr/bin/env python3
"""
RuleGenerator — Prisma Generator (Python proof-of-concept)
Mirrors the C# implementation exactly. Produces the same output files.
Run this to verify the generator produces correct output from the YAML definitions.

Usage:
  python3 generate.py \
    --prepared-items OrderEntry/prepared-items.yaml \
    --entities       OrderEntry/entities.yaml \
    --rules          OrderEntry/rules.yaml \
    --output         generated
"""

import yaml
import re
import os
import sys
import argparse
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

# =============================================================================
# MODELS
# =============================================================================

@dataclass
class ResolvedType:
    id: str
    base: str
    validation_pattern: Optional[str] = None
    validation_error: Optional[str] = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    currency_aware: bool = False
    constraints: list = field(default_factory=list)

@dataclass
class ResolvedEnum:
    id: str
    description: str
    values: list
    transitions: Optional[dict] = None

    @property
    def pascal_name(self):
        return ''.join(w.capitalize() for w in self.id.split('_'))

@dataclass
class ResolvedField:
    name: str
    description: str
    kind: str  # 'scalar' | 'enum' | 'reference'
    required: bool = True
    unique: bool = False
    primary_key: bool = False
    default: object = None
    # scalar
    primitive_type: Optional[str] = None
    prepared_type_id: Optional[str] = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    validation_pattern: Optional[str] = None
    type_constraints: list = field(default_factory=list)
    # enum
    enum_type: Optional['ResolvedEnum'] = None
    # reference
    referenced_entity: Optional['ResolvedEntity'] = None

    @property
    def foreign_key_column(self):
        return f"{self.name}Id" if self.kind == 'reference' else None

@dataclass
class ResolvedEntity:
    id: str
    description: str
    table_name: str
    fields: list = field(default_factory=list)
    indexes: list = field(default_factory=list)
    audit: bool = False
    soft_delete: bool = False

@dataclass
class ResolvedDomain:
    entities: list = field(default_factory=list)
    enums: list = field(default_factory=list)
    types: list = field(default_factory=list)
    rules: list = field(default_factory=list)

# =============================================================================
# RESOLUTION
# =============================================================================

PRIMITIVES = {'text','integer','boolean','uuid','decimal',
              'timestamp','date','time','jsonb','bytea'}

def to_snake_case(pascal):
    s = re.sub(r'(?<!^)(?=[A-Z])', '_', pascal).lower()
    return s

def resolve(prepared_items, entity_defs, rule_defs):
    type_index = {t['id']: t for t in prepared_items.get('types', [])}
    enum_index  = {e['id']: e for e in prepared_items.get('enums', [])}
    constraint_index = {c['id']: c for c in prepared_items.get('constraints', [])}
    temporal_index   = {t['id']: t for t in prepared_items.get('temporal', [])}
    operator_set = set(prepared_items.get('operators', []))

    # Resolve enums
    resolved_enums = {}
    for e in prepared_items.get('enums', []):
        re_enum = ResolvedEnum(
            id=e['id'],
            description=e.get('description', ''),
            values=e['values'],
            transitions=e.get('transitions')
        )
        resolved_enums[e['id']] = re_enum

    # Resolve types
    resolved_types = {}
    for t in prepared_items.get('types', []):
        resolved_types[t['id']] = ResolvedType(
            id=t['id'],
            base=t['base'],
            validation_pattern=t.get('validation'),
            validation_error=t.get('error'),
            precision=t.get('precision'),
            scale=t.get('scale'),
            currency_aware=t.get('currency_aware', False),
            constraints=t.get('constraints', [])
        )

    # First pass — entity stubs
    entity_stubs = {}
    for e in entity_defs.get('entities', []):
        table = e.get('table') or to_snake_case(e['id']) + 's'
        entity_stubs[e['id']] = ResolvedEntity(
            id=e['id'],
            description=e.get('description', ''),
            table_name=table,
            indexes=e.get('indexes', []),
            audit=e.get('audit', False),
            soft_delete=e.get('soft_delete', False)
        )

    # Second pass — resolve fields
    for entity_def in entity_defs.get('entities', []):
        resolved = entity_stubs[entity_def['id']]
        resolved.fields = resolve_fields(
            entity_def, type_index, resolved_enums, resolved_types, entity_stubs)

        if entity_def.get('audit'):
            resolved.fields += audit_fields()
        if entity_def.get('soft_delete'):
            resolved.fields.append(scalar_field('deletedAt', 'timestamp',
                'When this record was soft deleted', required=False))

    # Validate rules
    rule_index = {r['id']: r for r in rule_defs.get('rules', [])}
    for rule in rule_defs.get('rules', []):
        validate_rule(rule, entity_stubs, constraint_index,
                      temporal_index, operator_set, rule_index)

    return ResolvedDomain(
        entities=list(entity_stubs.values()),
        enums=list(resolved_enums.values()),
        types=list(resolved_types.values()),
        rules=rule_defs.get('rules', [])
    )

def resolve_fields(entity_def, type_index, enum_index, type_lookup, entity_stubs):
    fields = []

    has_pk = any(f.get('primary_key') for f in entity_def.get('fields', []))
    if not has_pk:
        fields.append(ResolvedField(
            name='id', description='Primary key', kind='scalar',
            primitive_type='uuid', required=True, primary_key=True, default='uuid()'))

    for f in entity_def.get('fields', []):
        type_id = f['type'].lower()
        rf = ResolvedField(
            name=f['name'],
            description=f.get('description', ''),
            kind='scalar',
            required=f.get('required', True),
            unique=f.get('unique', False),
            primary_key=f.get('primary_key', False),
            default=f.get('default')
        )

        if f['type'] == 'reference':
            target_id = f.get('entity')
            if not target_id or target_id not in entity_stubs:
                raise ValueError(f"Field '{f['name']}' on '{entity_def['id']}' "
                                 f"references unknown entity '{target_id}'")
            rf.kind = 'reference'
            rf.referenced_entity = entity_stubs[target_id]

        elif type_id in enum_index:
            rf.kind = 'enum'
            rf.enum_type = enum_index[type_id]

        elif type_id in type_lookup:
            pt = type_lookup[type_id]
            rf.kind = 'scalar'
            rf.prepared_type_id = type_id
            rf.primitive_type = pt.base
            rf.precision = pt.precision
            rf.scale = pt.scale
            rf.validation_pattern = pt.validation_pattern
            rf.type_constraints = pt.constraints

        elif type_id in PRIMITIVES:
            rf.kind = 'scalar'
            rf.primitive_type = type_id

        else:
            raise ValueError(f"Field '{f['name']}' on '{entity_def['id']}' "
                             f"has unknown type '{f['type']}'")

        fields.append(rf)
    return fields

def audit_fields():
    return [
        scalar_field('createdAt', 'timestamp', 'When this record was created', default='now()'),
        scalar_field('updatedAt', 'timestamp', 'When this record was last updated', default='now()')
    ]

def scalar_field(name, ptype, desc, required=True, default=None):
    return ResolvedField(name=name, description=desc, kind='scalar',
                         primitive_type=ptype, required=required, default=default)

def validate_rule(rule, entity_stubs, constraint_index, temporal_index,
                  operator_set, rule_index):
    if rule['entity'] not in entity_stubs:
        raise ValueError(f"Rule '{rule['id']}' references unknown entity '{rule['entity']}'")
    for dep in rule.get('depends_on', []):
        if dep not in rule_index:
            raise ValueError(f"Rule '{rule['id']}' depends_on unknown rule '{dep}'")
    if rule.get('overrides') and rule['overrides'] not in rule_index:
        raise ValueError(f"Rule '{rule['id']}' overrides unknown rule '{rule['overrides']}'")

# =============================================================================
# PRISMA GENERATOR
# =============================================================================

PRISMA_TYPE_MAP = {
    'text': 'String', 'integer': 'Int', 'boolean': 'Boolean',
    'uuid': 'String', 'decimal': 'Decimal', 'timestamp': 'DateTime',
    'date': 'DateTime', 'time': 'String', 'jsonb': 'Json', 'bytea': 'Bytes'
}

DB_TYPE_MAP = {
    'uuid': '@db.Uuid', 'text': '@db.Text',
    'timestamp': '@db.Timestamp(6)', 'date': '@db.Date',
    'time': '@db.Time(6)', 'jsonb': '@db.JsonB', 'bytea': '@db.ByteA'
}

SQL_OPERATOR_MAP = {
    'eq': '=', 'not_eq': '!=', 'gt': '>', 'gte': '>=', 'lt': '<', 'lte': '<='
}

PG_TYPE_MAP = {
    'text': 'TEXT', 'integer': 'INTEGER', 'boolean': 'BOOLEAN',
    'uuid': 'UUID', 'timestamp': 'TIMESTAMPTZ', 'date': 'DATE',
    'time': 'TIME', 'jsonb': 'JSONB', 'bytea': 'BYTEA'
}

def now_utc():
    return datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')

def generate_prisma(domain, output_path):
    os.makedirs(output_path, exist_ok=True)
    migrations_path = os.path.join(output_path, 'migrations')
    os.makedirs(migrations_path, exist_ok=True)

    schema = build_prisma_schema(domain)
    domains_sql = build_domains_sql(domain)
    checks_sql = build_checks_sql(domain)
    transitions_sql = build_transitions_sql(domain)

    write(os.path.join(output_path, 'schema.prisma'), schema)
    write(os.path.join(migrations_path, '001_domains.sql'), domains_sql)
    write(os.path.join(migrations_path, '002_checks.sql'), checks_sql)
    write(os.path.join(migrations_path, '003_transitions.sql'), transitions_sql)

    print(f"  schema.prisma")
    print(f"  migrations/001_domains.sql")
    print(f"  migrations/002_checks.sql")
    print(f"  migrations/003_transitions.sql")

# --- Prisma Schema ---

def build_prisma_schema(domain):
    out = []
    out.append(prisma_header())
    out.append('generator client {\n  provider = "prisma-client-js"\n}\n')
    out.append('datasource db {\n  provider = "postgresql"\n  url      = env("DATABASE_URL")\n}\n')

    if domain.enums:
        out.append('// ' + '=' * 77)
        out.append('// ENUMS')
        out.append('// ' + '=' * 77 + '\n')
        for e in domain.enums:
            out.append(write_enum(e))

    out.append('// ' + '=' * 77)
    out.append('// MODELS')
    out.append('// ' + '=' * 77 + '\n')
    for entity in domain.entities:
        out.append(write_model(entity))

    return '\n'.join(out)

def prisma_header():
    return (f"// {'=' * 77}\n"
            f"// Prisma Schema — generated by RuleGenerator\n"
            f"// Generated: {now_utc()}\n"
            f"// DO NOT EDIT — regenerate from YAML definitions\n"
            f"// {'=' * 77}\n")

def write_enum(e):
    lines = []
    if e.description:
        lines.append(f'/// {e.description}')
    lines.append(f'enum {e.pascal_name} {{')
    for v in e.values:
        lines.append(f'  {v}')
    lines.append('}\n')
    return '\n'.join(lines)

def write_model(entity):
    lines = []
    if entity.description:
        lines.append(f'/// {entity.description}')
    lines.append(f'model {entity.id} {{')

    for f in entity.fields:
        lines.append(f'  {build_field_line(f)}')

    # FK scalar columns for relations
    for f in entity.fields:
        if f.kind == 'reference':
            fk = f'{f.name}Id'
            type_str = 'String' if f.required else 'String?'
            lines.append(f'  {fk}  {type_str}  @db.Uuid')

    lines.append('')

    for idx in entity.indexes:
        fields_str = ', '.join(idx.get('fields', []))
        if idx.get('unique'):
            lines.append(f'  @@unique([{fields_str}])')
        else:
            lines.append(f'  @@index([{fields_str}])')

    lines.append(f'  @@map("{entity.table_name}")')
    lines.append('}\n')
    return '\n'.join(lines)

def build_field_line(f):
    parts = [f.name, '  ']

    if f.kind == 'enum':
        type_str = f.enum_type.pascal_name + ('' if f.required else '?')
        parts.append(type_str)
        if f.default is not None:
            parts.append(f'  @default({f.enum_type.pascal_name}.{f.default})')

    elif f.kind == 'reference':
        ref = f.referenced_entity.id + ('' if f.required else '?')
        parts.append(f'{ref}  @relation(fields: [{f.name}Id], references: [id])')

    else:  # scalar
        prim = f.primitive_type or 'text'
        prisma_type = PRISMA_TYPE_MAP.get(prim, 'String')
        type_str = prisma_type + ('' if f.required else '?')
        parts.append(type_str + '  ')

        attrs = []
        if f.primary_key:
            attrs += ['@id', '@default(uuid())']
        elif f.default is not None:
            attrs.append(f'@default({format_default(f.default, prim)})')

        if f.unique:
            attrs.append('@unique')

        if prim == 'decimal' and f.precision and f.scale:
            attrs.append(f'@db.Decimal({f.precision}, {f.scale})')
        elif prim in DB_TYPE_MAP:
            attrs.append(DB_TYPE_MAP[prim])

        if attrs:
            parts.append('  '.join(attrs))

    return ''.join(parts)

def format_default(value, prim):
    if str(value) in ('now()', 'uuid()'):
        return str(value)
    if prim == 'boolean':
        return str(value).lower()
    if prim in ('integer', 'decimal'):
        return str(value)
    return f'"{value}"'

# --- Domains SQL ---

def build_domains_sql(domain):
    out = [sql_header('Postgres Domain Types'),
           '-- Named domain types enforcing prepared item constraints.\n']

    for t in domain.types:
        if not t.constraints and not t.validation_pattern:
            continue

        pg_base = pg_type(t.base, t.precision, t.scale)
        checks = []
        if t.validation_pattern:
            checks.append(f"VALUE ~ '{t.validation_pattern}'")
        for c in t.constraints:
            checks.append(f"VALUE {sql_op(c['operator'])} {c['value']}")

        check_clause = f'\n  CHECK ({" AND ".join(checks)})' if checks else ''
        comment = f'  -- {t.validation_error}' if t.validation_error else ''

        out.append(f'-- {t.id}')
        out.append(f'CREATE DOMAIN {t.id} AS {pg_base}{check_clause};{comment}')
        out.append('')

    return '\n'.join(out)

# --- Checks SQL ---

def build_checks_sql(domain):
    out = [sql_header('Column Check Constraints'),
           '-- Applied after Prisma migration to enforce type-level rules.\n']

    for entity in domain.entities:
        constrained = [f for f in entity.fields
                       if f.kind == 'scalar' and f.type_constraints]
        if not constrained:
            continue

        out.append(f'-- {entity.id}')
        for f in constrained:
            col = to_snake_case(f.name)
            tbl = entity.table_name
            for c in f.type_constraints:
                name = f"chk_{tbl}_{col}_{c['operator']}"
                out.append(f'ALTER TABLE {tbl}')
                out.append(f'  DROP CONSTRAINT IF EXISTS {name};')
                out.append(f'ALTER TABLE {tbl}')
                out.append(f'  ADD CONSTRAINT {name}')
                out.append(f"  CHECK ({col} {sql_op(c['operator'])} {c['value']});")
                out.append('')

    return '\n'.join(out)

# --- Transitions SQL ---

def build_transitions_sql(domain):
    out = [sql_header('State Transition Enforcement Triggers'),
           '-- PL/pgSQL triggers enforcing valid enum state transitions.\n']

    for entity in domain.entities:
        transition_fields = [f for f in entity.fields
                             if f.kind == 'enum' and f.enum_type
                             and f.enum_type.transitions]
        for f in transition_fields:
            out.append(write_transition_trigger(entity, f))

    return '\n'.join(out)

def write_transition_trigger(entity, f):
    tbl = entity.table_name
    col = to_snake_case(f.name)
    func_name = f'enforce_{tbl}_{col}_transition'
    trigger_name = f'trg_{tbl}_{col}'
    transitions = f.enum_type.transitions

    lines = [f'-- {entity.id}.{f.name} state transition enforcement',
             f'CREATE OR REPLACE FUNCTION {func_name}()',
             'RETURNS TRIGGER AS $$',
             'BEGIN',
             f'  IF OLD.{col} = NEW.{col} THEN',
             '    RETURN NEW;',
             '  END IF;',
             '',
             f'  CASE OLD.{col}']

    for from_state, to_states in transitions.items():
        lines.append(f"    WHEN '{from_state}' THEN")
        if not to_states:
            lines.append(f"      RAISE EXCEPTION 'Invalid transition: % is a terminal "
                         f"state for {entity.id}.{f.name}', OLD.{col};")
        else:
            allowed = ', '.join(f"'{s}'" for s in to_states)
            lines.append(f'      IF NEW.{col} NOT IN ({allowed}) THEN')
            lines.append(f"        RAISE EXCEPTION 'Invalid transition on {entity.id}.{f.name}: "
                         f"% → %. Allowed: {', '.join(to_states)}',")
            lines.append(f'          OLD.{col}, NEW.{col};')
            lines.append('      END IF;')

    lines += ['  END CASE;', '', '  RETURN NEW;', 'END;',
              '$$ LANGUAGE plpgsql;', '',
              f'DROP TRIGGER IF EXISTS {trigger_name} ON {tbl};',
              f'CREATE TRIGGER {trigger_name}',
              f'  BEFORE UPDATE ON {tbl}',
              f'  FOR EACH ROW',
              f'  EXECUTE FUNCTION {func_name}();',
              '', '-' * 79, '']

    return '\n'.join(lines)

# --- Utilities ---

def sql_header(title):
    return (f"-- {'=' * 77}\n"
            f"-- {title}\n"
            f"-- Generated: {now_utc()}\n"
            f"-- DO NOT EDIT — regenerate from YAML definitions\n"
            f"-- {'=' * 77}\n")

def pg_type(base, precision, scale):
    if base == 'decimal' and precision and scale:
        return f'DECIMAL({precision},{scale})'
    return PG_TYPE_MAP.get(base, base.upper())

def sql_op(op):
    return SQL_OPERATOR_MAP.get(op, op)

def write(path, content):
    with open(path, 'w') as fh:
        fh.write(content)

# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description='RuleGenerator — Prisma Generator')
    parser.add_argument('--prepared-items', required=True)
    parser.add_argument('--entities', required=True)
    parser.add_argument('--rules', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()

    print()
    print('RuleGenerator')
    print('=' * 60)
    print(f'  Prepared items : {args.prepared_items}')
    print(f'  Entities       : {args.entities}')
    print(f'  Rules          : {args.rules}')
    print(f'  Output         : {args.output}')
    print()

    print('[load] Reading definition files...')
    with open(args.prepared_items) as f:
        prepared_items = yaml.safe_load(f)
    with open(args.entities) as f:
        entity_defs = yaml.safe_load(f)
    with open(args.rules) as f:
        rule_defs = yaml.safe_load(f)

    print(f"[load] {len(prepared_items.get('types',[]))} types, "
          f"{len(prepared_items.get('enums',[]))} enums, "
          f"{len(prepared_items.get('temporal',[]))} temporals, "
          f"{len(prepared_items.get('constraints',[]))} constraints")
    print(f"[load] {len(entity_defs.get('entities',[]))} entities")
    print(f"[load] {len(rule_defs.get('rules',[]))} rules")
    print()

    print('[resolve] Wiring cross-references and validating...')
    domain = resolve(prepared_items, entity_defs, rule_defs)
    print(f'[resolve] OK — {len(domain.entities)} entities resolved')
    print()

    print('[prisma] Generating...')
    prisma_output = os.path.join(args.output, 'prisma')
    generate_prisma(domain, prisma_output)
    print(f'[prisma] Done → {prisma_output}')
    print()
    print('=' * 60)
    print('Generation complete.')

if __name__ == '__main__':
    main()
