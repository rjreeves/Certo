namespace RuleGenerator.Models;

/// <summary>
/// Root container for all shared vocabulary definitions.
/// These are referenced by entity and rule definitions.
/// </summary>
public class PreparedItems
{
    public string Version { get; set; } = "1.0";
    public List<TypeDefinition> Types { get; set; } = new();
    public List<EnumDefinition> Enums { get; set; } = new();
    public List<TemporalDefinition> Temporal { get; set; } = new();
    public List<ConstraintDefinition> Constraints { get; set; } = new();
    public List<string> Operators { get; set; } = new();
}

/// <summary>
/// A named scalar type with base type, validation, and constraints.
/// Examples: email, money, percentage
/// </summary>
public class TypeDefinition
{
    public string Id { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    /// <summary>Postgres base type: text, decimal, integer, boolean, uuid, timestamp</summary>
    public string Base { get; set; } = string.Empty;

    /// <summary>Optional regex pattern for text types</summary>
    public string? Validation { get; set; }

    /// <summary>Human readable validation error message</summary>
    public string? Error { get; set; }

    /// <summary>For decimal types</summary>
    public int? Precision { get; set; }
    public int? Scale { get; set; }

    /// <summary>Whether this type carries currency context</summary>
    public bool CurrencyAware { get; set; }

    /// <summary>Value constraints applied to this type</summary>
    public List<ConstraintExpression> Constraints { get; set; } = new();
}

/// <summary>
/// A named enum with values and optional valid state transitions.
/// Examples: order_status, user_role
/// </summary>
public class EnumDefinition
{
    public string Id { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public List<string> Values { get; set; } = new();

    /// <summary>
    /// Valid state transitions. Key is current state, value is list of reachable states.
    /// If null, no transition rules are enforced.
    /// </summary>
    public Dictionary<string, List<string>>? Transitions { get; set; }
}

/// <summary>
/// A named time window used in temporal business rules.
/// Examples: standard_void_window (30 days)
/// </summary>
public class TemporalDefinition
{
    public string Id { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int Duration { get; set; }
    public TemporalUnit Unit { get; set; }
}

public enum TemporalUnit
{
    Minutes,
    Hours,
    Days,
    Weeks,
    Months,
    Years
}

/// <summary>
/// A named reusable condition fragment referenced by rules.
/// Examples: within_credit_limit
/// </summary>
public class ConstraintDefinition
{
    public string Id { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public ConditionNode Condition { get; set; } = new();
}

/// <summary>
/// A simple field-level constraint used within type definitions.
/// Examples: gte: 0, lte: 100
/// </summary>
public class ConstraintExpression
{
    public string Operator { get; set; } = string.Empty;
    public object Value { get; set; } = new();
}
