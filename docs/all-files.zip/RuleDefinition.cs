namespace RuleGenerator.Models;

/// <summary>
/// Root container for rule definitions loaded from rules.yaml
/// </summary>
public class RuleDefinitions
{
    public string Version { get; set; } = "1.0";
    public List<RuleDefinition> Rules { get; set; } = new();
}

/// <summary>
/// A single business rule governing an entity operation.
/// </summary>
public class RuleDefinition
{
    public string Id { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    /// <summary>Entity id this rule applies to e.g. Order, Invoice</summary>
    public string Entity { get; set; } = string.Empty;

    /// <summary>Operation that activates this rule e.g. submit, void, create</summary>
    public string Trigger { get; set; } = string.Empty;

    /// <summary>Higher priority wins when rules conflict. Default 0.</summary>
    public int Priority { get; set; }

    /// <summary>Rule ids that must pass before this rule is evaluated.</summary>
    public List<string> DependsOn { get; set; } = new();

    /// <summary>Rule id this rule suspends when its own condition passes.</summary>
    public string? Overrides { get; set; }

    public ConditionNode Condition { get; set; } = new();
    public RuleError Error { get; set; } = new();
    public RuleTargets? Targets { get; set; }
}

/// <summary>
/// Recursive condition tree node.
/// Either a composite (All/Any/None) or a leaf condition.
/// </summary>
public class ConditionNode
{
    // --- Composite nodes ---
    public List<ConditionNode>? All { get; set; }
    public List<ConditionNode>? Any { get; set; }
    public List<ConditionNode>? None { get; set; }

    // --- Leaf: field comparison ---
    /// <summary>Dot-notation field path e.g. user.verified, order.total</summary>
    public string? Field { get; set; }

    /// <summary>Operator from prepared items operators list</summary>
    public string? Operator { get; set; }

    /// <summary>Literal value or dot-notation field reference</summary>
    public object? Value { get; set; }

    /// <summary>Time unit for temporal operators e.g. days, hours</summary>
    public string? Unit { get; set; }

    // --- Leaf: named constraint reference ---
    /// <summary>Constraint id from prepared items</summary>
    public string? Constraint { get; set; }

    // --- Leaf: named temporal reference ---
    /// <summary>Temporal id from prepared items</summary>
    public string? Temporal { get; set; }

    public bool IsComposite => All != null || Any != null || None != null;
    public bool IsFieldComparison => Field != null && Operator != null;
    public bool IsConstraintRef => Constraint != null;
    public bool IsTemporalRef => Temporal != null && Field != null;
}

/// <summary>
/// Error emitted when a rule is violated.
/// </summary>
public class RuleError
{
    public string Code { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}

/// <summary>
/// Per-generator configuration for a rule.
/// Controls what each generator emits.
/// </summary>
public class RuleTargets
{
    public ApiTarget? Api { get; set; }
    public UiTarget? Ui { get; set; }
    public TestTarget? Test { get; set; }
    public DocsTarget? Docs { get; set; }
}

public class ApiTarget
{
    public bool Middleware { get; set; } = true;
    public string Layer { get; set; } = "before_handler";
}

public class UiTarget
{
    public string? Behaviour { get; set; }
    public string? Field { get; set; }
    public string? Tooltip { get; set; }
}

public class TestTarget
{
    public bool Generate { get; set; } = true;
    public List<Dictionary<string, object>> Cases { get; set; } = new();
}

public class DocsTarget
{
    public bool Visible { get; set; } = true;
    public string? Category { get; set; }
}
