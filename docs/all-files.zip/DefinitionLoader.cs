using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;
using RuleGenerator.Models;

namespace RuleGenerator.Parsing;

/// <summary>
/// Loads and deserialises the three YAML definition files into C# models.
/// Uses camelCase and snake_case naming conventions matching the YAML schema.
/// </summary>
public class DefinitionLoader
{
    private readonly IDeserializer _deserializer;

    public DefinitionLoader()
    {
        _deserializer = new DeserializerBuilder()
            .WithNamingConvention(UnderscoredNamingConvention.Instance)
            .IgnoreUnmatchedProperties()
            .Build();
    }

    public PreparedItems LoadPreparedItems(string path)
    {
        var yaml = ReadFile(path);
        var result = _deserializer.Deserialize<PreparedItems>(yaml);
        return result ?? throw new InvalidDataException(
            $"Failed to deserialise prepared items from {path}");
    }

    public EntityDefinitions LoadEntities(string path)
    {
        var yaml = ReadFile(path);
        var result = _deserializer.Deserialize<EntityDefinitions>(yaml);
        return result ?? throw new InvalidDataException(
            $"Failed to deserialise entities from {path}");
    }

    public RuleDefinitions LoadRules(string path)
    {
        var yaml = ReadFile(path);
        var result = _deserializer.Deserialize<RuleDefinitions>(yaml);
        return result ?? throw new InvalidDataException(
            $"Failed to deserialise rules from {path}");
    }

    private static string ReadFile(string path)
    {
        if (!File.Exists(path))
            throw new FileNotFoundException($"Definition file not found: {path}");
        return File.ReadAllText(path);
    }
}
