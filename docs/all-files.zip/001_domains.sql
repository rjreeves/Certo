-- =============================================================================
-- Postgres Domain Types
-- Generated: 2026-06-15 19:29:36 UTC
-- DO NOT EDIT — regenerate from YAML definitions
-- =============================================================================

-- Named domain types enforcing prepared item constraints.

-- email
CREATE DOMAIN email AS TEXT
  CHECK (VALUE ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$');  -- Must be a valid email address

-- money
CREATE DOMAIN money AS DECIMAL(10,2)
  CHECK (VALUE >= 0);

-- percentage
CREATE DOMAIN percentage AS DECIMAL(5,2)
  CHECK (VALUE >= 0 AND VALUE <= 100);

-- short_text
CREATE DOMAIN short_text AS TEXT
  CHECK (VALUE <= 255);

-- positive_integer
CREATE DOMAIN positive_integer AS INTEGER
  CHECK (VALUE > 0);

-- non_negative_integer
CREATE DOMAIN non_negative_integer AS INTEGER
  CHECK (VALUE >= 0);

-- phone
CREATE DOMAIN phone AS TEXT
  CHECK (VALUE ~ '^\+?[1-9]\d{6,14}$');  -- Must be a valid international phone number

-- postal_code
CREATE DOMAIN postal_code AS TEXT
  CHECK (VALUE ~ '^[A-Z0-9][A-Z0-9\s\-]{2,9}$');  -- Must be a valid postal code

-- tax_number
CREATE DOMAIN tax_number AS TEXT
  CHECK (VALUE ~ '^[A-Z0-9\-]{5,20}$');  -- Must be a valid tax registration number

-- sku
CREATE DOMAIN sku AS TEXT
  CHECK (VALUE ~ '^[A-Z0-9\-]{3,20}$');  -- Must be a valid SKU e.g. PROD-001

-- currency_code
CREATE DOMAIN currency_code AS TEXT
  CHECK (VALUE ~ '^[A-Z]{3}$');  -- Must be a valid ISO 4217 currency code e.g. USD, GBP, EUR

-- url
CREATE DOMAIN url AS TEXT
  CHECK (VALUE ~ '^https?:\/\/.+');  -- Must be a valid URL
