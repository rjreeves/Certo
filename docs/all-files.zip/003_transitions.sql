-- =============================================================================
-- State Transition Enforcement Triggers
-- Generated: 2026-06-15 19:29:36 UTC
-- DO NOT EDIT — regenerate from YAML definitions
-- =============================================================================

-- PL/pgSQL triggers enforcing valid enum state transitions.

-- Customer.status state transition enforcement
CREATE OR REPLACE FUNCTION enforce_customers_status_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  CASE OLD.status
    WHEN 'PROSPECT' THEN
      IF NEW.status NOT IN ('ACTIVE', 'CLOSED') THEN
        RAISE EXCEPTION 'Invalid transition on Customer.status: % → %. Allowed: ACTIVE, CLOSED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'ACTIVE' THEN
      IF NEW.status NOT IN ('ON_HOLD', 'SUSPENDED', 'CLOSED') THEN
        RAISE EXCEPTION 'Invalid transition on Customer.status: % → %. Allowed: ON_HOLD, SUSPENDED, CLOSED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'ON_HOLD' THEN
      IF NEW.status NOT IN ('ACTIVE', 'SUSPENDED', 'CLOSED') THEN
        RAISE EXCEPTION 'Invalid transition on Customer.status: % → %. Allowed: ACTIVE, SUSPENDED, CLOSED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'SUSPENDED' THEN
      IF NEW.status NOT IN ('ACTIVE', 'CLOSED') THEN
        RAISE EXCEPTION 'Invalid transition on Customer.status: % → %. Allowed: ACTIVE, CLOSED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'CLOSED' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Customer.status', OLD.status;
  END CASE;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_customers_status ON customers;
CREATE TRIGGER trg_customers_status
  BEFORE UPDATE ON customers
  FOR EACH ROW
  EXECUTE FUNCTION enforce_customers_status_transition();

-------------------------------------------------------------------------------

-- Order.status state transition enforcement
CREATE OR REPLACE FUNCTION enforce_orders_status_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  CASE OLD.status
    WHEN 'DRAFT' THEN
      IF NEW.status NOT IN ('SUBMITTED', 'CANCELLED') THEN
        RAISE EXCEPTION 'Invalid transition on Order.status: % → %. Allowed: SUBMITTED, CANCELLED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'SUBMITTED' THEN
      IF NEW.status NOT IN ('APPROVED', 'CANCELLED') THEN
        RAISE EXCEPTION 'Invalid transition on Order.status: % → %. Allowed: APPROVED, CANCELLED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'APPROVED' THEN
      IF NEW.status NOT IN ('PICKING', 'CANCELLED') THEN
        RAISE EXCEPTION 'Invalid transition on Order.status: % → %. Allowed: PICKING, CANCELLED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'PICKING' THEN
      IF NEW.status NOT IN ('SHIPPED', 'CANCELLED') THEN
        RAISE EXCEPTION 'Invalid transition on Order.status: % → %. Allowed: SHIPPED, CANCELLED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'SHIPPED' THEN
      IF NEW.status NOT IN ('DELIVERED', 'RETURNED') THEN
        RAISE EXCEPTION 'Invalid transition on Order.status: % → %. Allowed: DELIVERED, RETURNED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'DELIVERED' THEN
      IF NEW.status NOT IN ('RETURNED') THEN
        RAISE EXCEPTION 'Invalid transition on Order.status: % → %. Allowed: RETURNED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'CANCELLED' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Order.status', OLD.status;
    WHEN 'RETURNED' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Order.status', OLD.status;
  END CASE;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_orders_status ON orders;
CREATE TRIGGER trg_orders_status
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION enforce_orders_status_transition();

-------------------------------------------------------------------------------

-- Shipment.status state transition enforcement
CREATE OR REPLACE FUNCTION enforce_shipments_status_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  CASE OLD.status
    WHEN 'PENDING' THEN
      IF NEW.status NOT IN ('DISPATCHED') THEN
        RAISE EXCEPTION 'Invalid transition on Shipment.status: % → %. Allowed: DISPATCHED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'DISPATCHED' THEN
      IF NEW.status NOT IN ('IN_TRANSIT') THEN
        RAISE EXCEPTION 'Invalid transition on Shipment.status: % → %. Allowed: IN_TRANSIT',
          OLD.status, NEW.status;
      END IF;
    WHEN 'IN_TRANSIT' THEN
      IF NEW.status NOT IN ('DELIVERED', 'FAILED_DELIVERY') THEN
        RAISE EXCEPTION 'Invalid transition on Shipment.status: % → %. Allowed: DELIVERED, FAILED_DELIVERY',
          OLD.status, NEW.status;
      END IF;
    WHEN 'DELIVERED' THEN
      IF NEW.status NOT IN ('RETURNED') THEN
        RAISE EXCEPTION 'Invalid transition on Shipment.status: % → %. Allowed: RETURNED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'FAILED_DELIVERY' THEN
      IF NEW.status NOT IN ('IN_TRANSIT', 'RETURNED') THEN
        RAISE EXCEPTION 'Invalid transition on Shipment.status: % → %. Allowed: IN_TRANSIT, RETURNED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'RETURNED' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Shipment.status', OLD.status;
  END CASE;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_shipments_status ON shipments;
CREATE TRIGGER trg_shipments_status
  BEFORE UPDATE ON shipments
  FOR EACH ROW
  EXECUTE FUNCTION enforce_shipments_status_transition();

-------------------------------------------------------------------------------

-- Invoice.status state transition enforcement
CREATE OR REPLACE FUNCTION enforce_invoices_status_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  CASE OLD.status
    WHEN 'DRAFT' THEN
      IF NEW.status NOT IN ('ISSUED') THEN
        RAISE EXCEPTION 'Invalid transition on Invoice.status: % → %. Allowed: ISSUED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'ISSUED' THEN
      IF NEW.status NOT IN ('PARTIALLY_PAID', 'PAID', 'OVERDUE', 'VOIDED') THEN
        RAISE EXCEPTION 'Invalid transition on Invoice.status: % → %. Allowed: PARTIALLY_PAID, PAID, OVERDUE, VOIDED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'PARTIALLY_PAID' THEN
      IF NEW.status NOT IN ('PAID', 'OVERDUE', 'VOIDED') THEN
        RAISE EXCEPTION 'Invalid transition on Invoice.status: % → %. Allowed: PAID, OVERDUE, VOIDED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'PAID' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Invoice.status', OLD.status;
    WHEN 'OVERDUE' THEN
      IF NEW.status NOT IN ('PARTIALLY_PAID', 'PAID', 'VOIDED', 'WRITTEN_OFF') THEN
        RAISE EXCEPTION 'Invalid transition on Invoice.status: % → %. Allowed: PARTIALLY_PAID, PAID, VOIDED, WRITTEN_OFF',
          OLD.status, NEW.status;
      END IF;
    WHEN 'VOIDED' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Invoice.status', OLD.status;
    WHEN 'WRITTEN_OFF' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Invoice.status', OLD.status;
  END CASE;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_invoices_status ON invoices;
CREATE TRIGGER trg_invoices_status
  BEFORE UPDATE ON invoices
  FOR EACH ROW
  EXECUTE FUNCTION enforce_invoices_status_transition();

-------------------------------------------------------------------------------

-- Payment.status state transition enforcement
CREATE OR REPLACE FUNCTION enforce_payments_status_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  CASE OLD.status
    WHEN 'PENDING' THEN
      IF NEW.status NOT IN ('PROCESSING', 'CANCELLED') THEN
        RAISE EXCEPTION 'Invalid transition on Payment.status: % → %. Allowed: PROCESSING, CANCELLED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'PROCESSING' THEN
      IF NEW.status NOT IN ('COMPLETED', 'FAILED') THEN
        RAISE EXCEPTION 'Invalid transition on Payment.status: % → %. Allowed: COMPLETED, FAILED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'COMPLETED' THEN
      IF NEW.status NOT IN ('REFUNDED') THEN
        RAISE EXCEPTION 'Invalid transition on Payment.status: % → %. Allowed: REFUNDED',
          OLD.status, NEW.status;
      END IF;
    WHEN 'FAILED' THEN
      IF NEW.status NOT IN ('PENDING') THEN
        RAISE EXCEPTION 'Invalid transition on Payment.status: % → %. Allowed: PENDING',
          OLD.status, NEW.status;
      END IF;
    WHEN 'REFUNDED' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Payment.status', OLD.status;
    WHEN 'CANCELLED' THEN
      RAISE EXCEPTION 'Invalid transition: % is a terminal state for Payment.status', OLD.status;
  END CASE;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_payments_status ON payments;
CREATE TRIGGER trg_payments_status
  BEFORE UPDATE ON payments
  FOR EACH ROW
  EXECUTE FUNCTION enforce_payments_status_transition();

-------------------------------------------------------------------------------
