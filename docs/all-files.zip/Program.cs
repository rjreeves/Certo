using RuleGenerator.Generators;
using RuleGenerator.Parsing;
using RuleGenerator.Resolution;

// =============================================================================
// RuleGenerator CLI
// =============================================================================
// Usage:
//   dotnet run -- generate \
//     --prepared-items <path> \
//     --entities <path> \
//     --rules <path> \
//     --output <directory> \
//     --targets prisma [csharp] [plpgsql]
// =============================================================================

if (args.Length == 0 || args[0] != "generate")
{
    PrintUsage();
    return 1;
}

// Parse arguments
var argMap = ParseArgs(args[1..]);

var preparedItemsPath = GetRequired(argMap, "prepared-items");
var entitiesPath      = GetRequired(argMap, "entities");
var rulesPath         = GetRequired(argMap, "rules");
var outputPath        = GetRequired(argMap, "output");
var targets           = argMap.GetValueOrDefault("targets", "prisma")
                              .Split(' ', StringSplitOptions.RemoveEmptyEntries);

Console.WriteLine();
Console.WriteLine("RuleGenerator");
Console.WriteLine(new string('=', 60));
Console.WriteLine($"  Prepared items : {preparedItemsPath}");
Console.WriteLine($"  Entities       : {entitiesPath}");
Console.WriteLine($"  Rules          : {rulesPath}");
Console.WriteLine($"  Output         : {outputPath}");
Console.WriteLine($"  Targets        : {string.Join(", ", targets)}");
Console.WriteLine();

try
{
    // 1. Load
    Console.WriteLine("[load] Reading definition files...");
    var loader = new DefinitionLoader();
    var preparedItems = loader.LoadPreparedItems(preparedItemsPath);
    var entityDefs    = loader.LoadEntities(entitiesPath);
    var ruleDefs      = loader.LoadRules(rulesPath);
    Console.WriteLine($"[load] {preparedItems.Types.Count} types, " +
                      $"{preparedItems.Enums.Count} enums, " +
                      $"{preparedItems.Temporal.Count} temporals, " +
                      $"{preparedItems.Constraints.Count} constraints");
    Console.WriteLine($"[load] {entityDefs.Entities.Count} entities");
    Console.WriteLine($"[load] {ruleDefs.Rules.Count} rules");
    Console.WriteLine();

    // 2. Resolve
    Console.WriteLine("[resolve] Wiring cross-references and validating...");
    var resolver = new DefinitionResolver();
    var domain = resolver.Resolve(preparedItems, entityDefs, ruleDefs);
    Console.WriteLine($"[resolve] OK — {domain.Entities.Count} entities resolved");
    Console.WriteLine();

    // 3. Generate
    var generators = BuildGenerators(targets);

    foreach (var generator in generators)
    {
        Console.WriteLine($"[{generator.Name}] Generating...");
        var genOutputPath = Path.Combine(outputPath, generator.Name);
        await generator.GenerateAsync(domain, genOutputPath);
        Console.WriteLine($"[{generator.Name}] Done → {genOutputPath}");
        Console.WriteLine();
    }

    Console.WriteLine(new string('=', 60));
    Console.WriteLine("Generation complete.");
    return 0;
}
catch (FileNotFoundException ex)
{
    Console.Error.WriteLine($"[error] File not found: {ex.Message}");
    return 2;
}
catch (RuleGenerator.Resolution.DefinitionException ex)
{
    Console.Error.WriteLine($"[error] Definition error: {ex.Message}");
    return 3;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"[error] Unexpected error: {ex.Message}");
    Console.Error.WriteLine(ex.StackTrace);
    return 99;
}

// =============================================================================
// Helpers
// =============================================================================

static IReadOnlyList<IGenerator> BuildGenerators(string[] targets)
{
    var generators = new List<IGenerator>();
    foreach (var target in targets)
    {
        generators.Add(target.ToLower() switch
        {
            "prisma" => new PrismaGenerator(),
            _ => throw new ArgumentException(
                $"Unknown target '{target}'. Supported: prisma")
        });
    }
    return generators;
}

static Dictionary<string, string> ParseArgs(string[] args)
{
    var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    for (int i = 0; i < args.Length - 1; i++)
    {
        if (args[i].StartsWith("--"))
        {
            var key = args[i][2..];
            // Collect all non-flag tokens as the value
            var values = new List<string>();
            while (i + 1 < args.Length && !args[i + 1].StartsWith("--"))
                values.Add(args[++i]);
            map[key] = string.Join(" ", values);
        }
    }
    return map;
}

static string GetRequired(Dictionary<string, string> args, string key)
{
    if (!args.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value))
    {
        Console.Error.WriteLine($"[error] Missing required argument: --{key}");
        Environment.Exit(1);
    }
    return value;
}

static void PrintUsage()
{
    Console.WriteLine("""
    RuleGenerator — generates Prisma schema and validators from YAML definitions

    Usage:
      dotnet run -- generate \
        --prepared-items <path/to/prepared-items.yaml> \
        --entities       <path/to/entities.yaml> \
        --rules          <path/to/rules.yaml> \
        --output         <output/directory> \
        --targets        prisma

    Example:
      dotnet run -- generate \
        --prepared-items OrderEntry/prepared-items.yaml \
        --entities       OrderEntry/entities.yaml \
        --rules          OrderEntry/rules.yaml \
        --output         generated \
        --targets        prisma
    """);
}
