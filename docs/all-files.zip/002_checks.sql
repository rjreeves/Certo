-- =============================================================================
-- Column Check Constraints
-- Generated: 2026-06-15 19:29:36 UTC
-- DO NOT EDIT — regenerate from YAML definitions
-- =============================================================================

-- Applied after Prisma migration to enforce type-level rules.

-- User
ALTER TABLE users
  DROP CONSTRAINT IF EXISTS chk_users_first_name_lte;
ALTER TABLE users
  ADD CONSTRAINT chk_users_first_name_lte
  CHECK (first_name <= 255);

ALTER TABLE users
  DROP CONSTRAINT IF EXISTS chk_users_last_name_lte;
ALTER TABLE users
  ADD CONSTRAINT chk_users_last_name_lte
  CHECK (last_name <= 255);

-- Customer
ALTER TABLE customers
  DROP CONSTRAINT IF EXISTS chk_customers_code_lte;
ALTER TABLE customers
  ADD CONSTRAINT chk_customers_code_lte
  CHECK (code <= 255);

ALTER TABLE customers
  DROP CONSTRAINT IF EXISTS chk_customers_name_lte;
ALTER TABLE customers
  ADD CONSTRAINT chk_customers_name_lte
  CHECK (name <= 255);

ALTER TABLE customers
  DROP CONSTRAINT IF EXISTS chk_customers_credit_limit_gte;
ALTER TABLE customers
  ADD CONSTRAINT chk_customers_credit_limit_gte
  CHECK (credit_limit >= 0);

ALTER TABLE customers
  DROP CONSTRAINT IF EXISTS chk_customers_available_credit_gte;
ALTER TABLE customers
  ADD CONSTRAINT chk_customers_available_credit_gte
  CHECK (available_credit >= 0);

ALTER TABLE customers
  DROP CONSTRAINT IF EXISTS chk_customers_tax_rate_gte;
ALTER TABLE customers
  ADD CONSTRAINT chk_customers_tax_rate_gte
  CHECK (tax_rate >= 0);

ALTER TABLE customers
  DROP CONSTRAINT IF EXISTS chk_customers_tax_rate_lte;
ALTER TABLE customers
  ADD CONSTRAINT chk_customers_tax_rate_lte
  CHECK (tax_rate <= 100);

ALTER TABLE customers
  DROP CONSTRAINT IF EXISTS chk_customers_payment_terms_days_gte;
ALTER TABLE customers
  ADD CONSTRAINT chk_customers_payment_terms_days_gte
  CHECK (payment_terms_days >= 0);

-- Address
ALTER TABLE addresses
  DROP CONSTRAINT IF EXISTS chk_addresses_line1_lte;
ALTER TABLE addresses
  ADD CONSTRAINT chk_addresses_line1_lte
  CHECK (line1 <= 255);

ALTER TABLE addresses
  DROP CONSTRAINT IF EXISTS chk_addresses_line2_lte;
ALTER TABLE addresses
  ADD CONSTRAINT chk_addresses_line2_lte
  CHECK (line2 <= 255);

ALTER TABLE addresses
  DROP CONSTRAINT IF EXISTS chk_addresses_city_lte;
ALTER TABLE addresses
  ADD CONSTRAINT chk_addresses_city_lte
  CHECK (city <= 255);

ALTER TABLE addresses
  DROP CONSTRAINT IF EXISTS chk_addresses_region_lte;
ALTER TABLE addresses
  ADD CONSTRAINT chk_addresses_region_lte
  CHECK (region <= 255);

ALTER TABLE addresses
  DROP CONSTRAINT IF EXISTS chk_addresses_country_lte;
ALTER TABLE addresses
  ADD CONSTRAINT chk_addresses_country_lte
  CHECK (country <= 255);

-- Contact
ALTER TABLE contacts
  DROP CONSTRAINT IF EXISTS chk_contacts_first_name_lte;
ALTER TABLE contacts
  ADD CONSTRAINT chk_contacts_first_name_lte
  CHECK (first_name <= 255);

ALTER TABLE contacts
  DROP CONSTRAINT IF EXISTS chk_contacts_last_name_lte;
ALTER TABLE contacts
  ADD CONSTRAINT chk_contacts_last_name_lte
  CHECK (last_name <= 255);

-- Product
ALTER TABLE products
  DROP CONSTRAINT IF EXISTS chk_products_name_lte;
ALTER TABLE products
  ADD CONSTRAINT chk_products_name_lte
  CHECK (name <= 255);

ALTER TABLE products
  DROP CONSTRAINT IF EXISTS chk_products_base_price_gte;
ALTER TABLE products
  ADD CONSTRAINT chk_products_base_price_gte
  CHECK (base_price >= 0);

ALTER TABLE products
  DROP CONSTRAINT IF EXISTS chk_products_cost_price_gte;
ALTER TABLE products
  ADD CONSTRAINT chk_products_cost_price_gte
  CHECK (cost_price >= 0);

ALTER TABLE products
  DROP CONSTRAINT IF EXISTS chk_products_margin_gte;
ALTER TABLE products
  ADD CONSTRAINT chk_products_margin_gte
  CHECK (margin >= 0);

ALTER TABLE products
  DROP CONSTRAINT IF EXISTS chk_products_stock_count_gte;
ALTER TABLE products
  ADD CONSTRAINT chk_products_stock_count_gte
  CHECK (stock_count >= 0);

ALTER TABLE products
  DROP CONSTRAINT IF EXISTS chk_products_reorder_level_gte;
ALTER TABLE products
  ADD CONSTRAINT chk_products_reorder_level_gte
  CHECK (reorder_level >= 0);

ALTER TABLE products
  DROP CONSTRAINT IF EXISTS chk_products_weight_gte;
ALTER TABLE products
  ADD CONSTRAINT chk_products_weight_gte
  CHECK (weight >= 0);

-- PriceList
ALTER TABLE price_lists
  DROP CONSTRAINT IF EXISTS chk_price_lists_code_lte;
ALTER TABLE price_lists
  ADD CONSTRAINT chk_price_lists_code_lte
  CHECK (code <= 255);

ALTER TABLE price_lists
  DROP CONSTRAINT IF EXISTS chk_price_lists_name_lte;
ALTER TABLE price_lists
  ADD CONSTRAINT chk_price_lists_name_lte
  CHECK (name <= 255);

-- PriceListEntry
ALTER TABLE price_list_entries
  DROP CONSTRAINT IF EXISTS chk_price_list_entries_price_gte;
ALTER TABLE price_list_entries
  ADD CONSTRAINT chk_price_list_entries_price_gte
  CHECK (price >= 0);

ALTER TABLE price_list_entries
  DROP CONSTRAINT IF EXISTS chk_price_list_entries_min_quantity_gt;
ALTER TABLE price_list_entries
  ADD CONSTRAINT chk_price_list_entries_min_quantity_gt
  CHECK (min_quantity > 0);

-- Order
ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS chk_orders_reference_lte;
ALTER TABLE orders
  ADD CONSTRAINT chk_orders_reference_lte
  CHECK (reference <= 255);

ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS chk_orders_subtotal_gte;
ALTER TABLE orders
  ADD CONSTRAINT chk_orders_subtotal_gte
  CHECK (subtotal >= 0);

ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS chk_orders_discount_total_gte;
ALTER TABLE orders
  ADD CONSTRAINT chk_orders_discount_total_gte
  CHECK (discount_total >= 0);

ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS chk_orders_tax_total_gte;
ALTER TABLE orders
  ADD CONSTRAINT chk_orders_tax_total_gte
  CHECK (tax_total >= 0);

ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS chk_orders_shipping_cost_gte;
ALTER TABLE orders
  ADD CONSTRAINT chk_orders_shipping_cost_gte
  CHECK (shipping_cost >= 0);

ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS chk_orders_total_gte;
ALTER TABLE orders
  ADD CONSTRAINT chk_orders_total_gte
  CHECK (total >= 0);

ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS chk_orders_customer_reference_lte;
ALTER TABLE orders
  ADD CONSTRAINT chk_orders_customer_reference_lte
  CHECK (customer_reference <= 255);

-- OrderLine
ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_quantity_gt;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_quantity_gt
  CHECK (quantity > 0);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_unit_price_gte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_unit_price_gte
  CHECK (unit_price >= 0);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_discount_percent_gte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_discount_percent_gte
  CHECK (discount_percent >= 0);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_discount_percent_lte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_discount_percent_lte
  CHECK (discount_percent <= 100);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_discount_amount_gte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_discount_amount_gte
  CHECK (discount_amount >= 0);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_tax_rate_gte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_tax_rate_gte
  CHECK (tax_rate >= 0);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_tax_rate_lte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_tax_rate_lte
  CHECK (tax_rate <= 100);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_tax_amount_gte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_tax_amount_gte
  CHECK (tax_amount >= 0);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_line_total_gte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_line_total_gte
  CHECK (line_total >= 0);

ALTER TABLE order_lines
  DROP CONSTRAINT IF EXISTS chk_order_lines_notes_lte;
ALTER TABLE order_lines
  ADD CONSTRAINT chk_order_lines_notes_lte
  CHECK (notes <= 255);

-- Discount
ALTER TABLE discounts
  DROP CONSTRAINT IF EXISTS chk_discounts_value_gte;
ALTER TABLE discounts
  ADD CONSTRAINT chk_discounts_value_gte
  CHECK (value >= 0);

ALTER TABLE discounts
  DROP CONSTRAINT IF EXISTS chk_discounts_reason_lte;
ALTER TABLE discounts
  ADD CONSTRAINT chk_discounts_reason_lte
  CHECK (reason <= 255);

-- Shipment
ALTER TABLE shipments
  DROP CONSTRAINT IF EXISTS chk_shipments_tracking_number_lte;
ALTER TABLE shipments
  ADD CONSTRAINT chk_shipments_tracking_number_lte
  CHECK (tracking_number <= 255);

ALTER TABLE shipments
  DROP CONSTRAINT IF EXISTS chk_shipments_carrier_lte;
ALTER TABLE shipments
  ADD CONSTRAINT chk_shipments_carrier_lte
  CHECK (carrier <= 255);

-- ShipmentLine
ALTER TABLE shipment_lines
  DROP CONSTRAINT IF EXISTS chk_shipment_lines_quantity_shipped_gt;
ALTER TABLE shipment_lines
  ADD CONSTRAINT chk_shipment_lines_quantity_shipped_gt
  CHECK (quantity_shipped > 0);

-- Invoice
ALTER TABLE invoices
  DROP CONSTRAINT IF EXISTS chk_invoices_reference_lte;
ALTER TABLE invoices
  ADD CONSTRAINT chk_invoices_reference_lte
  CHECK (reference <= 255);

ALTER TABLE invoices
  DROP CONSTRAINT IF EXISTS chk_invoices_subtotal_gte;
ALTER TABLE invoices
  ADD CONSTRAINT chk_invoices_subtotal_gte
  CHECK (subtotal >= 0);

ALTER TABLE invoices
  DROP CONSTRAINT IF EXISTS chk_invoices_tax_total_gte;
ALTER TABLE invoices
  ADD CONSTRAINT chk_invoices_tax_total_gte
  CHECK (tax_total >= 0);

ALTER TABLE invoices
  DROP CONSTRAINT IF EXISTS chk_invoices_total_gte;
ALTER TABLE invoices
  ADD CONSTRAINT chk_invoices_total_gte
  CHECK (total >= 0);

ALTER TABLE invoices
  DROP CONSTRAINT IF EXISTS chk_invoices_amount_paid_gte;
ALTER TABLE invoices
  ADD CONSTRAINT chk_invoices_amount_paid_gte
  CHECK (amount_paid >= 0);

ALTER TABLE invoices
  DROP CONSTRAINT IF EXISTS chk_invoices_amount_outstanding_gte;
ALTER TABLE invoices
  ADD CONSTRAINT chk_invoices_amount_outstanding_gte
  CHECK (amount_outstanding >= 0);

-- Payment
ALTER TABLE payments
  DROP CONSTRAINT IF EXISTS chk_payments_amount_gte;
ALTER TABLE payments
  ADD CONSTRAINT chk_payments_amount_gte
  CHECK (amount >= 0);

ALTER TABLE payments
  DROP CONSTRAINT IF EXISTS chk_payments_reference_lte;
ALTER TABLE payments
  ADD CONSTRAINT chk_payments_reference_lte
  CHECK (reference <= 255);

-- CreditNote
ALTER TABLE credit_notes
  DROP CONSTRAINT IF EXISTS chk_credit_notes_reference_lte;
ALTER TABLE credit_notes
  ADD CONSTRAINT chk_credit_notes_reference_lte
  CHECK (reference <= 255);

ALTER TABLE credit_notes
  DROP CONSTRAINT IF EXISTS chk_credit_notes_amount_gte;
ALTER TABLE credit_notes
  ADD CONSTRAINT chk_credit_notes_amount_gte
  CHECK (amount >= 0);
