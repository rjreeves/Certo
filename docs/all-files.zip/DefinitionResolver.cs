using RuleGenerator.Models;

namespace RuleGenerator.Resolution;

/// <summary>
/// Resolves all cross-references between prepared items, entities, and rules.
/// Produces a ResolvedDomain where every reference is wired up and validated.
/// Throws DefinitionException with clear messages on any inconsistency.
/// </summary>
public class DefinitionResolver
{
    private static readonly HashSet<string> Primitives = new(StringComparer.OrdinalIgnoreCase)
    {
        "text", "integer", "boolean", "uuid", "decimal",
        "timestamp", "date", "time", "jsonb", "bytea"
    };

    public ResolvedDomain Resolve(
        PreparedItems preparedItems,
        EntityDefinitions entityDefs,
        RuleDefinitions ruleDefs)
    {
        // Build lookup indexes
        var typeIndex = preparedItems.Types.ToDictionary(t => t.Id);
        var enumIndex = preparedItems.Enums.ToDictionary(e => e.Id);
        var constraintIndex = preparedItems.Constraints.ToDictionary(c => c.Id);
        var temporalIndex = preparedItems.Temporal.ToDictionary(t => t.Id);
        var operatorSet = new HashSet<string>(preparedItems.Operators);

        // Resolve enums first — entities reference them
        var resolvedEnums = preparedItems.Enums.Select(e => new ResolvedEnum
        {
            Id = e.Id,
            Description = e.Description,
            Values = e.Values,
            Transitions = e.Transitions
        }).ToList();

        var enumLookup = resolvedEnums.ToDictionary(e => e.Id);

        // Resolve prepared types
        var resolvedTypes = preparedItems.Types.Select(t => new ResolvedType
        {
            Id = t.Id,
            Base = t.Base,
            ValidationPattern = t.Validation,
            ValidationError = t.Error,
            Precision = t.Precision,
            Scale = t.Scale,
            CurrencyAware = t.CurrencyAware,
            Constraints = t.Constraints
        }).ToList();

        var typeLookup = resolvedTypes.ToDictionary(t => t.Id);

        // First pass — build entity stubs so references can resolve
        var entityStubs = entityDefs.Entities.ToDictionary(
            e => e.Id,
            e => new ResolvedEntity
            {
                Id = e.Id,
                Description = e.Description,
                TableName = e.Table ?? ToSnakeCase(e.Id) + "s",
                Audit = e.Audit,
                SoftDelete = e.SoftDelete,
                Indexes = e.Indexes
            });

        // Second pass — resolve fields
        foreach (var entityDef in entityDefs.Entities)
        {
            var resolved = entityStubs[entityDef.Id];
            resolved.Fields = ResolveFields(
                entityDef, typeIndex, enumLookup, typeLookup, entityStubs);

            // Add audit fields if requested
            if (entityDef.Audit)
                resolved.Fields.AddRange(AuditFields(entityStubs));

            // Add soft delete field if requested
            if (entityDef.SoftDelete)
                resolved.Fields.Add(SoftDeleteField());
        }

        // Validate rules
        var ruleIndex = ruleDefs.Rules.ToDictionary(r => r.Id);
        foreach (var rule in ruleDefs.Rules)
            ValidateRule(rule, entityStubs, constraintIndex, temporalIndex,
                operatorSet, ruleIndex);

        return new ResolvedDomain
        {
            Entities = entityStubs.Values.ToList(),
            Enums = resolvedEnums,
            Types = resolvedTypes,
            Rules = ruleDefs.Rules
        };
    }

    // -------------------------------------------------------------------------
    // Field resolution
    // -------------------------------------------------------------------------

    private static List<ResolvedField> ResolveFields(
        EntityDefinition entityDef,
        Dictionary<string, TypeDefinition> typeIndex,
        Dictionary<string, ResolvedEnum> enumLookup,
        Dictionary<string, ResolvedType> typeLookup,
        Dictionary<string, ResolvedEntity> entityStubs)
    {
        var fields = new List<ResolvedField>();

        // Auto primary key unless entity declares one explicitly
        var hasPk = entityDef.Fields.Any(f => f.PrimaryKey);
        if (!hasPk)
        {
            fields.Add(new ResolvedField
            {
                Name = "id",
                Description = "Primary key",
                Kind = FieldKind.Scalar,
                PrimitiveType = "uuid",
                Required = true,
                PrimaryKey = true,
                Default = "uuid()"
            });
        }

        foreach (var field in entityDef.Fields)
        {
            var resolved = new ResolvedField
            {
                Name = field.Name,
                Description = field.Description,
                Required = field.Required,
                Unique = field.Unique,
                PrimaryKey = field.PrimaryKey,
                Default = field.Default
            };

            var typeId = field.Type.ToLower();

            if (field.Type == "reference")
            {
                // Reference field → FK to another entity
                if (string.IsNullOrEmpty(field.Entity))
                    throw new DefinitionException(
                        $"Field '{field.Name}' on '{entityDef.Id}' is type 'reference'" +
                        " but has no 'entity' property.");

                if (!entityStubs.TryGetValue(field.Entity, out var target))
                    throw new DefinitionException(
                        $"Field '{field.Name}' on '{entityDef.Id}' references " +
                        $"unknown entity '{field.Entity}'.");

                resolved.Kind = FieldKind.Reference;
                resolved.ReferencedEntity = target;
            }
            else if (enumLookup.TryGetValue(typeId, out var enumDef))
            {
                // Enum field
                resolved.Kind = FieldKind.Enum;
                resolved.EnumType = enumDef;
            }
            else if (typeLookup.TryGetValue(typeId, out var preparedType))
            {
                // Prepared scalar type
                resolved.Kind = FieldKind.Scalar;
                resolved.PreparedTypeId = typeId;
                resolved.PrimitiveType = preparedType.Base;
                resolved.Precision = preparedType.Precision;
                resolved.Scale = preparedType.Scale;
                resolved.ValidationPattern = preparedType.ValidationPattern;
                resolved.TypeConstraints = preparedType.Constraints;
            }
            else if (Primitives.Contains(field.Type))
            {
                // Raw primitive
                resolved.Kind = FieldKind.Scalar;
                resolved.PrimitiveType = field.Type.ToLower();
            }
            else
            {
                throw new DefinitionException(
                    $"Field '{field.Name}' on '{entityDef.Id}' has unknown type '{field.Type}'. " +
                    "Must be a prepared type id, enum id, primitive, or 'reference'.");
            }

            fields.Add(resolved);
        }

        return fields;
    }

    // -------------------------------------------------------------------------
    // Audit and soft-delete fields
    // -------------------------------------------------------------------------

    private static IEnumerable<ResolvedField> AuditFields(
        Dictionary<string, ResolvedEntity> entityStubs)
    {
        yield return Scalar("createdAt", "timestamp", "When this record was created",
            defaultValue: "now()");
        yield return Scalar("updatedAt", "timestamp", "When this record was last updated",
            defaultValue: "now()");
    }

    private static ResolvedField SoftDeleteField() =>
        Scalar("deletedAt", "timestamp", "When this record was soft deleted",
            required: false);

    private static ResolvedField Scalar(
        string name, string type, string description,
        bool required = true, object? defaultValue = null) =>
        new()
        {
            Name = name,
            Description = description,
            Kind = FieldKind.Scalar,
            PrimitiveType = type,
            Required = required,
            Default = defaultValue
        };

    // -------------------------------------------------------------------------
    // Rule validation
    // -------------------------------------------------------------------------

    private static void ValidateRule(
        RuleDefinition rule,
        Dictionary<string, ResolvedEntity> entityStubs,
        Dictionary<string, ConstraintDefinition> constraintIndex,
        Dictionary<string, TemporalDefinition> temporalIndex,
        HashSet<string> operatorSet,
        Dictionary<string, RuleDefinition> ruleIndex)
    {
        if (!entityStubs.ContainsKey(rule.Entity))
            throw new DefinitionException(
                $"Rule '{rule.Id}' references unknown entity '{rule.Entity}'.");

        foreach (var dep in rule.DependsOn)
            if (!ruleIndex.ContainsKey(dep))
                throw new DefinitionException(
                    $"Rule '{rule.Id}' depends_on unknown rule '{dep}'.");

        if (rule.Overrides != null && !ruleIndex.ContainsKey(rule.Overrides))
            throw new DefinitionException(
                $"Rule '{rule.Id}' overrides unknown rule '{rule.Overrides}'.");

        ValidateConditionNode(rule.Condition, rule.Id,
            constraintIndex, temporalIndex, operatorSet);
    }

    private static void ValidateConditionNode(
        ConditionNode node, string ruleId,
        Dictionary<string, ConstraintDefinition> constraintIndex,
        Dictionary<string, TemporalDefinition> temporalIndex,
        HashSet<string> operatorSet)
    {
        if (node.IsComposite)
        {
            var children = node.All ?? node.Any ?? node.None ?? new();
            foreach (var child in children)
                ValidateConditionNode(child, ruleId,
                    constraintIndex, temporalIndex, operatorSet);
        }
        else if (node.IsConstraintRef)
        {
            if (!constraintIndex.ContainsKey(node.Constraint!))
                throw new DefinitionException(
                    $"Rule '{ruleId}' references unknown constraint '{node.Constraint}'.");
        }
        else if (node.IsTemporalRef)
        {
            if (!temporalIndex.ContainsKey(node.Temporal!))
                throw new DefinitionException(
                    $"Rule '{ruleId}' references unknown temporal '{node.Temporal}'.");
        }
        else if (node.IsFieldComparison)
        {
            if (!operatorSet.Contains(node.Operator!))
                throw new DefinitionException(
                    $"Rule '{ruleId}' uses unknown operator '{node.Operator}'.");
        }
    }

    // -------------------------------------------------------------------------
    // Utilities
    // -------------------------------------------------------------------------

    /// <summary>
    /// Converts PascalCase to snake_case.
    /// OrderLine → order_line
    /// </summary>
    public static string ToSnakeCase(string pascal)
    {
        var result = new System.Text.StringBuilder();
        for (int i = 0; i < pascal.Length; i++)
        {
            if (i > 0 && char.IsUpper(pascal[i]))
                result.Append('_');
            result.Append(char.ToLower(pascal[i]));
        }
        return result.ToString();
    }
}

public class DefinitionException : Exception
{
    public DefinitionException(string message) : base(message) { }
}
