namespace RuleGenerator.Models;

/// <summary>
/// The fully resolved domain model produced by DefinitionResolver.
/// All cross-references are wired up. This is what generators consume.
/// </summary>
public class ResolvedDomain
{
    public List<ResolvedEntity> Entities { get; set; } = new();
    public List<ResolvedEnum> Enums { get; set; } = new();
    public List<ResolvedType> Types { get; set; } = new();
    public List<RuleDefinition> Rules { get; set; } = new();

    public ResolvedEntity? FindEntity(string id) =>
        Entities.FirstOrDefault(e => e.Id == id);

    public ResolvedEnum? FindEnum(string id) =>
        Enums.FirstOrDefault(e => e.Id == id);

    public ResolvedType? FindType(string id) =>
        Types.FirstOrDefault(t => t.Id == id);
}

/// <summary>
/// An entity with all field types resolved to their base representations.
/// </summary>
public class ResolvedEntity
{
    public string Id { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string TableName { get; set; } = string.Empty;
    public List<ResolvedField> Fields { get; set; } = new();
    public List<IndexDefinition> Indexes { get; set; } = new();
    public bool Audit { get; set; }
    public bool SoftDelete { get; set; }
}

/// <summary>
/// A field with its type fully resolved — primitives, enums, references all
/// normalised into a single discriminated form.
/// </summary>
public class ResolvedField
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public FieldKind Kind { get; set; }
    public bool Required { get; set; }
    public bool Unique { get; set; }
    public bool PrimaryKey { get; set; }
    public object? Default { get; set; }

    // Scalar fields
    public string? PrimitiveType { get; set; }    // text, integer, boolean etc.
    public string? PreparedTypeId { get; set; }   // original prepared type id
    public int? Precision { get; set; }
    public int? Scale { get; set; }
    public string? ValidationPattern { get; set; }
    public List<ConstraintExpression> TypeConstraints { get; set; } = new();

    // Enum fields
    public ResolvedEnum? EnumType { get; set; }

    // Reference fields
    public ResolvedEntity? ReferencedEntity { get; set; }

    /// <summary>Derived FK column name for reference fields e.g. userId</summary>
    public string? ForeignKeyColumn =>
        Kind == FieldKind.Reference ? $"{Name}Id" : null;
}

public enum FieldKind
{
    Scalar,
    Enum,
    Reference
}

/// <summary>
/// A resolved enum with values and optional transition map.
/// </summary>
public class ResolvedEnum
{
    public string Id { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public List<string> Values { get; set; } = new();
    public Dictionary<string, List<string>>? Transitions { get; set; }

    /// <summary>PascalCase Prisma/C# enum name e.g. order_status → OrderStatus</summary>
    public string PascalName => ToPascalCase(Id);

    private static string ToPascalCase(string snake) =>
        string.Concat(snake.Split('_')
            .Select(w => char.ToUpper(w[0]) + w[1..].ToLower()));
}

/// <summary>
/// A resolved prepared type with all constraints expanded.
/// </summary>
public class ResolvedType
{
    public string Id { get; set; } = string.Empty;
    public string Base { get; set; } = string.Empty;
    public string? ValidationPattern { get; set; }
    public string? ValidationError { get; set; }
    public int? Precision { get; set; }
    public int? Scale { get; set; }
    public bool CurrencyAware { get; set; }
    public List<ConstraintExpression> Constraints { get; set; } = new();
}
